== README ==

This folder contains the following:
- ToyProblem/* (a folder containing code for running asymmetric actor-critic experiments on a simplified toy problem)
- GeneralGym/* (a folder containing code for running asymmetric actor-critic experiments on registered Gym environments)

Please check the individual subfolders listed above for readmes and specific instructions for usage.