import re
from setuptools import setup, find_packages
import sys

if sys.version_info.major != 3:
    print('This Python is only compatible with Python 3, but you are running '
          'Python {}. The installation will likely fail.'.format(sys.version_info.major))

setup(name='asymmetric-ac',
      version='0.0.1',
      description='Test bed for investigating asymmetric actor-critic architecture in Reinforcement Learning',
      packages=find_packages(),
      install_requires=['gym', 'numpy', 'noise', 'tensorflow', 'mpi4py'],
)
