import os, subprocess, sys
import os.path as osp
import numpy as np
import asymmetric_ac.utils.test_policy as test_policy

def test(fpath, num_episodes=20, length=None):
    print(fpath)
    test_results = []
    for dir in os.listdir(fpath):
        env, get_action = test_policy.load_policy_and_env(osp.join(fpath,dir), 'last', deterministic=True)
        test_results.append(np.mean(test_policy.run_policy(env, get_action, length, num_episodes, render=False)))
    return test_results

def int_tuples_to_strings(l):
    return list(map(lambda int_elem: str(int_elem), l))

def train_then_test(alg, env_name, epochs, num_seeds, q_hid, a_hid):
    computed_name = env_name + "_binary_search_" + alg + "_q" + str(q_hid) + "_a" + str(a_hid)
    seeds = list(map(lambda seed: str(seed), range(0,num_seeds)))
    subprocess.call(["python", "-m", "asymmetric_ac.run", alg,
        "--env", env_name,
        "--epochs", str(epochs),
        "--exp_name", computed_name] + 
        ["--q_hid"] + int_tuples_to_strings(q_hid) +
        ["--a_hid"] + int_tuples_to_strings(a_hid) + 
        ["--seed"] + seeds
    )
    return np.mean(test(osp.join("data", computed_name)))

def binary_int_search(f_test, low, high):
    def search(low, high):
        if high <= low:
            return low
        else:
            mid = (high + low) // 2
            if f_test(mid):
                return search(low, mid-1)
            else:
                return search(mid+1, high)
    return search(low,high)


def search(alg, env_name, epochs, num_seeds, solve_reward):
    hiddenSizes = [(1,), (1,1), (2,2), (4,4), (8,8), (16,16), (32,16), (32,32), (64,32), (64,64), (128, 64), (128,128), (256, 128), (256,256)]
    trace = []

    def index_solves(index):
        reward = train_then_test(alg, env_name, epochs, num_seeds, q_hid=hiddenSizes[index], a_hid=hiddenSizes[index])
        trace.append("net_size: " + str(hiddenSizes[index]) + ", reward: " + str(reward))
        return reward >= solve_reward

    smallest_viable_size = hiddenSizes[binary_int_search(index_solves, 0, len(hiddenSizes)-1)]
    print("#################### TRACE #####################")
    for t in trace:
        print(t)
    return smallest_viable_size


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--alg', type=str, default="ddpg")
    parser.add_argument('--num_seeds', type=int, default=3)
    # parser.add_argument('--episodes', '-n', type=int, default=100)
    parser.add_argument('--env_name', type=str, default="Pendulum-v0")
    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--solve_reward', type=int, default=-200)
    args = vars(parser.parse_args())
    print(search(**args))
