# Disable TF deprecation warnings.
# Syntax from tf1 is not expected to be compatible with tf2.
import tensorflow as tf
tf.logging.set_verbosity(tf.logging.ERROR)

# Algorithms
from asymmetric_ac.algs.ddpg.ddpg import ddpg as ddpg_tf1
from asymmetric_ac.algs.ppo.ppo import ppo as ppo_tf1
from asymmetric_ac.algs.baseline_ppo.ppo.trainer import train as baseline_ppo_tf1
from asymmetric_ac.algs.sac.sac import sac as sac_tf1
from asymmetric_ac.algs.discrete_sac.discrete_sac import sac as discrete_sac_tf1
from asymmetric_ac.algs.td3.td3 import td3 as td3_tf1
from asymmetric_ac.algs.trpo.trpo import trpo as trpo_tf1
from asymmetric_ac.algs.vpg.vpg import vpg as vpg_tf1

# from spinup.algos.pytorch.ddpg.ddpg import ddpg as ddpg_pytorch
# from spinup.algos.pytorch.ppo.ppo import ppo as ppo_pytorch
# from spinup.algos.pytorch.sac.sac import sac as sac_pytorch
# from spinup.algos.pytorch.td3.td3 import td3 as td3_pytorch
# from spinup.algos.pytorch.trpo.trpo import trpo as trpo_pytorch
# from spinup.algos.pytorch.vpg.vpg import vpg as vpg_pytorch

# Loggers
from asymmetric_ac.utils.logx import Logger, EpochLogger

# Version
from asymmetric_ac.version import __version__