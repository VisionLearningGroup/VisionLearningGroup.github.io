# RL Smoothness

Asymmetric AC is a Python library for studying actor-critic asymmetry in deep RL.

Based on Spinning Up code from OpenAI.

## Installation

### Via pip
It is recommended to set up a python [virtual environment](https://docs.python.org/3/library/venv.html) and enter it, then:
```bash
pip install -r requirements.txt
pip install -e .
```

## Usage

Example: Train an agent with DDPG on the Pendulum-v0 environment with actor (a_hid) and critic (q_hid) sizes (64,64):
```bash
python -m asymmetric_ac.run ddpg --a_hid 64 64 --q_hid 64 64 --env Pendulum-v0
```

*Note* PPO critic size set with ```--v_hid``` flag instead of ```q_hid```


Supported algorithms are:
```bash
baseline_ppo
ddpg
td3
sac
discrete_sac
```

Example: run binary search for DDPG on Pendulum-v0 over 50 epochs on 6 seeds and attempting to get an average reward of -150:
```bash
python -m asymmetric_ac.run binary_search --alg ddpg --epochs 50 --num_seeds 6 --solve_reward -150 --env_name Pendulum-v0
```


## Asymmetry Implementation location
Most changes relating to supporting actor-critic asymmetry can be found in the core files for each algorithm.


## References

[OpenAI gym](https://gym.openai.com/)

[Spinning up](https://spinningup.openai.com/en/latest/index.html)
