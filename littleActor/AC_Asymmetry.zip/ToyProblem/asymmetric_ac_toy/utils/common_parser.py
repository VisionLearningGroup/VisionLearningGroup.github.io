import numpy as np
from envs.GoalGenerationEnv import functions


def add_common_args(parser):
    parser.add_argument('--seed', '-s', type=int, default=np.random.randint(0, 1e6))
    parser.add_argument('--goal_type', type=str, help='Set the goal generation type. Default: step', choices=functions, default='simplex')
    parser.add_argument('--test_goal_type', type=str, help='Sets the testing environment goal generation. Default: simplex', choices=functions, default=None)
    parser.add_argument('--env_dynamics', type=str, help='Set enviornment state control mode - direct or with dynamics. Default: state (direct)', choices={'state', 'velocity', 'acceleration'}, default='state')
    parser.add_argument('--act_mode', type=str, help='Set relative or absolute action mode. Defauilt: relative', choices={'absolute', 'relative'}, default='relative')
    parser.add_argument('--reg_a', help='', type=int, default=None)
    parser.add_argument('--reg_s', help='', type=int, default=None)
    parser.add_argument('--s_eps', type=float, help='', default=0.05)

    parser.add_argument('--dt', type=float, help='delta_time', default=0.02)
    parser.add_argument('--max_time', type=float, help='', default=3.)

    parser.add_argument('--deterministic', '-d', help='Use determinisitic agents? - only affects PPO, TRPO and SAC', action='store_true')
    parser.add_argument('--test_target', '-T', help='(For off policy algs only) Test target policy?', action='store_true')

    parser.add_argument('--test_period', '-tp', type=int, help='How often to test agent and display output', default=20)
    parser.add_argument('--action_distr_test_period', '-adtp', type=int, help='How often to test the action distribution', default=-1)
    parser.add_argument('--compare_filtered', help='Compare filtered vs non-filtered actions?', action='store_true')

    
    parser.add_argument('--gamma', type=float, default=0.99)
    parser.add_argument('--epochs', type=int, default=100)

    return parser