import pickle
import matplotlib.pyplot as plt

def plot_following(files):
    f,ax = plt.subplots(2,1,sharex=True,squeeze=True,figsize=(15,7))
    for i, file in enumerate(files):
        (feedback_list, setpoint_list, time_list, outputs, alg_name) = pickle.load(open(file, "rb"))
        if i == 0:
            ax[0].plot(time_list, setpoint_list, label='Set-point')
        ax[0].plot(time_list, feedback_list, label=alg_name)
        ax[0].set_ylabel('State')
        ax[0].grid(True)
        ax[0].legend()

        ax[1].plot(time_list, outputs, label=alg_name)
        ax[1].set_xlabel('time (s)')
        ax[1].set_ylabel('Action')
        ax[1].grid(True)
        ax[1].legend()
        
    f.suptitle('Agent tests')
    f.show()
