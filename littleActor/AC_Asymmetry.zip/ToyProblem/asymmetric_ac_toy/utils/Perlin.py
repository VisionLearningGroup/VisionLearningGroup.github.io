import math
import numpy as np

def grad(i, x):
    h = i & 0xf
    grad = 1 + (h & 7)
    sign = 1 if (h & 8) == 0 else -1
    return sign * grad * x


perm = np.random.randint(0, high=256, size=256)
perm = np.hstack((perm,perm))

def perlin(x, perm=perm):
    i0 = math.floor(x)
    i1 = i0 + 1

    x0 = x - i0
    x1 = x0 - 1

    t0 = 1 - x0 * x0
    t0 *= t0

    t1 = 1 - x1 * x1
    t1 *= t1

    n0 = t0 * t0 * grad(perm[i0 & 0xff], x0)
    n1 = t1 * t1 * grad(perm[i1 & 0xff], x1)

    return 0.395 * (n0 + n1) #Output is between -1 and 1.


def perlin(x, octaves):
    