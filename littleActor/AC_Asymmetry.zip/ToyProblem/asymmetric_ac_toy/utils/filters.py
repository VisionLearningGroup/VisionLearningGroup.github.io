import scipy.signal as signal
import numpy as np


class Stateful():
    def __init__(self, init_state, stateful_fun):
        self.state = init_state
        self.stateful_fun = stateful_fun

    def step(self, val):
        self.state, new_val = self.stateful_fun(self.state, val)
        return new_val

def windowed(squash_window, window_size=5): #squash_window is function from a window to the "filtered" output
    def windowed_step(window, new_val):
        window.append(new_val)
        if len(window) > window_size:
            window = window[1:]
        filtered_val = squash_window(np.array(window).flatten()) if len(window) == window_size else new_val
        return window, filtered_val
    return Stateful([], windowed_step)

# def Savitzky-Golay_filter():
#     return windowed(lambda window: signal.savgol_filter(window, 5, 2)[-2])

def Median_filter():
    return windowed(np.median, window_size=3)

# def mean_filter():
#     return windowed(np.mean, window_size=3)

def Butterworth_filter():
    b, a = signal.butter(3, 0.5,'low', analog=False)
    def butter_filter_fun(state, val):
        filtered_val, new_state = signal.lfilter(b, a, [val], zi=state)
        return new_state, filtered_val  
    return Stateful(signal.lfilter_zi(b, a), butter_filter_fun)

def FIR_filter():
    b = signal.firwin(3, 0.5)
    def fir_filter_fun(state,val):
        filtered_val, new_state = signal.lfilter(b, 1, [val], zi=state)
        return new_state, filtered_val      
    return Stateful(signal.lfilter_zi(b, 1), fir_filter_fun)

def EMA_filter():
    def moving_avg(old_state, new_val, filter_scale = 0.6):
        new_state = new_val*filter_scale + (1-filter_scale)*old_state
        return new_state, new_state
    return Stateful(0, moving_avg)

def Unfiltered_filter():
    return Stateful(0, lambda s, a: (s,a))


def dict_step(dict_of_statefuls, val):
    new_val_dict = dict_of_statefuls.copy()
    for (name, stateful) in dict_of_statefuls.items():
        new_val_dict[name] = stateful.step(val)
    return new_val_dict

filters_dict = { key[:-len("_filter")] : value
    for (key,value) in locals().items()
    if key.endswith("filter") }

def inited_filters():
    return { key : value()
             for (key,value) in filters_dict.items() }
