from envs.StateEnv import StateEnv
import envs.GoalGenerationEnv as goalGeneration
from PIDactor import PID
import pickle

import numpy as np
import matplotlib.pyplot as plt
import asymmetric_ac_toy.utils.filters as filters

def test_pid(filter_name, P = 0.2,  I = 0.0, D= 0.0, max_sim_time=4):
    """Self-test PID class

    .. note::
        ...
        for i in range(1, END):
            pid.update(feedback)
            output = pid.output
            if pid.SetPoint > 0:
                feedback += (output - (1/i))
            if i>9:
                pid.SetPoint = 1
            time.sleep(0.02)
        ---
    """
    env = StateEnv(max_time=max_sim_time, goal_fun=goalGeneration.functions['step'])
    state = env.reset()
    error = state[0]

    pid = PID(P, I, D)

    done = False
    feedback = 0

    feedback_list = []
    time_list = []
    outputs = []
    setpoint_list = []
    filter_state = filters.inited_filters()[filter_name]

    while not done:
        a = pid.act(error)
        filtered_a = np.array(filter_state.step(a if np.isscalar(a) else a[0]))
        # filtered_a = a
        outputs.append(filtered_a)
        state, _, done, info = env.step(filtered_a)

        error = state[0]

        goal = info['goal']

        feedback_list.append((goal-error))
        setpoint_list.append(goal)
        time_list.append(info['sim_time'])

    # time_sm = np.array(time_list)
    # time_smooth = np.linspace(time_sm.min(), time_sm.max(), 300)

    # feedback_smooth = spline(time_list, feedback_list, time_smooth)
    # Using make_interp_spline to create BSpline
    # helper_x3 = make_interp_spline(time_list, feedback_list)
    # feedback_smooth = helper_x3(time_smooth)

    f,(ax1,ax2) = plt.subplots(2,1,sharex=True, squeeze=True, figsize=(3,3))
    ax1.set_title(filter_name + " PID")
    ax1.plot(time_list, feedback_list, label='State')
    ax1.plot(time_list, setpoint_list, label='Target')
    # ax1.set_xlabel('time (s)')
    # ax1.set_ylabel('State')
    ax1.grid(True)
    ax1.legend()

    ax2.plot(time_list, outputs, label='Action')
    # ax2.set_xlabel('time (s)')
    # ax2.set_ylabel('Action')
    ax2.grid(True)
    ax2.legend()
    pickle.dump((outputs,feedback_list), open("pid_critical_damping/" + filter_name + ".p", "wb"))
    pickle.dump(setpoint_list, open("pid_critical_damping/setpoints/setpoints.p", "wb"))

    plt.savefig("pid_critical_damping/"+filter_name+"_pid.pdf")

if __name__ == "__main__":
    # test_pid(1.2, 1, 0.001, L=50)
    for k in filters.filters_dict.keys():
        test_pid(k, 0.3, 0.0, 0.00, max_sim_time=10)
#    test_pid(0.8, L=50)