from gym import spaces
import numpy as np
from .GoalGenerationEnv import GoalGenerationEnv


class DegEnv(GoalGenerationEnv):
    def __init__(self, goal=0, **kwargs):
        super().__init__(goal_fun=lambda x: goal, **kwargs)

        self.obs_high = np.array([10., 10.])
        self.max_act = np.array([10.])

        self.observation_space = spaces.Box(low=-self.obs_high, high=self.obs_high)
        self.action_space = spaces.Box(low=-self.max_act, high=self.max_act)

        self.state = self.goal

    def step(self, u):
        done, info = super().step(u)

        u = np.clip(u, -self.max_act, self.max_act)
        
        self.state += 2*np.random.rand()-1

        reward = -np.abs(self.goal - u)

        state_return = np.concatenate((self.goal-self.state, self.state))

        return state_return, reward, done, info

    def reset(self):
        super().reset()
        self.state = self.goal.copy()
        state_return = np.concatenate((self.goal-self.state, self.state))

        return state_return