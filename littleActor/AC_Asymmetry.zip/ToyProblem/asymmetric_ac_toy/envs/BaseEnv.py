from gym.utils import seeding

class BaseEnv():
    def __init__(self, dt=0.02, max_time=3., starting_seed=0):
        self.sim_time = 0.
        self.max_time = max_time
        self.dt = dt
        self.done = False
        self.seed(starting_seed)

    def seed(self, new_seed):
        self.np_random, _ = seeding.np_random(new_seed)
        self.current_seed = new_seed

    def step(self):
        self.sim_time += self.dt
        if self.sim_time > self.max_time:
            self.done = True

        return self.done, {'sim_time':self.sim_time}

    def reset(self):
        self.seed(self.current_seed + 13)
        self.sim_time = 0.
        self.done = False