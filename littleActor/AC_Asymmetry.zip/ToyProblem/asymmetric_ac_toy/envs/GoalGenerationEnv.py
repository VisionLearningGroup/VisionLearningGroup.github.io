import noise
import math
import numpy as np
from .BaseEnv import BaseEnv
from functools import partial

def clamp(x, min_, max_):
    return min(max(x, min_), max_)

def transform(x, domain=(0.,1.), range=(-1.,1.)):
    from_min, from_max = domain
    to_min, to_max = range
    from_range = from_max - from_min
    to_range = to_max - to_min
    return clamp(((x-from_min)/from_range)*to_range + to_min, to_min, to_max)

def rand(time, seed=0, box=(-1.,1.)): #cheap fake hash function from any real to reals between 0 and 1
    rand01 = math.modf((12.9348*math.modf(math.sin(time * 58.5453123 + seed*3872.93)*234.293)[0])**2)[0]
    return transform(rand01, range=box)

def discretize(f, freq=1.):
    return lambda time, seed: f(math.floor(time*freq)/freq, seed) 

def simplex(box=(-1.,1.), base_freq=1):
    return lambda time, seed: transform(noise.snoise2(time*base_freq, seed, 4), (-0.75, 0.75), box)

def discontinuous(f, discontinuous_freq=1, time_range=0.15):
    def with_time_seed(time, seed):
        discontiue_amount = discretize(rand, freq=0.3)(time, seed)
        time += time_range*discontiue_amount**2
        return f(time, seed)
    return with_time_seed

def multi_seeder(f, repetitions):
    return lambda time, seed: np.array([
        f(time, seed+i*3.287382) for i in range(repetitions)])

functions = {
    'step': discretize(partial(rand, box=(-1.,1.)), freq=0.3),
    'simplex': simplex(),
    'dsimplex': discretize(simplex(), freq=100),
    'discontinuous': discontinuous(simplex()),
    'constant': lambda x, seed: 0.
}

class GoalGenerationEnv(BaseEnv):

    def __init__(self, goal_fun=simplex, **kwargs):
        super().__init__(**kwargs)
        self.goal_fun = goal_fun
        self.set_goal()

    def set_goal(self):
        self.goal = np.array([self.goal_fun(self.sim_time, self.current_seed)])

    def step(self):
        (done, info) = super().step()
        self.set_goal()
        info['goal'] = self.goal
        return (done, info)

    def reset(self):
        return_me = super().reset()
        self.set_goal()
        return return_me

