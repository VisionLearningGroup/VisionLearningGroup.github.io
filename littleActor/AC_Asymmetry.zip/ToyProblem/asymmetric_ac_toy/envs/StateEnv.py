from .GoalGenerationEnv import GoalGenerationEnv

from gym import spaces
import numpy as np

class StateEnv(GoalGenerationEnv):
    def __init__(self, action_type='R', **kwargs):
        super().__init__(**kwargs)

        self.max_act = np.array([1.])
        self.obs_high = np.array([1.])

        self.action_space = spaces.Box(low=-self.max_act, high=self.max_act)
        self.observation_space = spaces.Box(low=-self.obs_high, high=self.obs_high)


        self.state = self.goal.copy()

    def step(self, u):
        done, info = super().step()

        u = np.clip(u, -self.max_act, self.max_act)

        self.state += u

        reward = -np.abs(self.goal - self.state)

        return (self.goal - self.state), reward, done, info

    def reset(self):
        super().reset()
        self.state = self.goal.copy()
        return self.state