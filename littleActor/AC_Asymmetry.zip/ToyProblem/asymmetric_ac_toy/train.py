
def training_dir_name(alg_name, rand_seed):
    import datetime
    now = datetime.datetime.now()
    timestamp = now.strftime('%y%m%d-%H%M%S')
    return '{alg_name}_t{timestamp}_rs{rand_seed}'.format(**locals())

def add_algs_subparser(parser):
    subparsers = parser.add_subparsers(title="algs", dest='alg_name', required=True)
    for alg in training_algs:
        subparser = subparsers.add_parser(alg.name())
        alg.add_args(subparser)

def parse_args(training_algs):
    import argparse
    parser = argparse.ArgumentParser()
    from utils.common_parser import add_common_args
    add_common_args(parser)
    add_algs_subparser(parser)

    return vars(parser.parse_args())

def add_env(args):
    from envs.StateEnv import StateEnv
    from envs.GoalGenerationEnv import functions
    if not args['test_goal_type']:
        args['test_goal_type'] = args['goal_type']
    args['env_fn'] = lambda: StateEnv(goal_fun=functions[args['goal_type']], dt=args['dt'], max_time=args['max_time'])
    args['test_env_fn'] = lambda: StateEnv(goal_fun=functions[args['test_goal_type']], dt=args['dt'], max_time=args['max_time'])

def handler(signal_received, frame):
    # Handle any cleanup here
    print('SIGINT or CTRL-C detected. Exiting gracefully')
    sys.exit(0)

if __name__ == '__main__':
    from signal import signal, SIGINT
    import os
    from os.path import join
    import pprint as pp
    import sys
    from asymmetric_ac_toy.train_alg import subclasses

    signal(SIGINT, handler)

    training_algs = subclasses()
    args = parse_args(training_algs)
    add_env(args)
    chosen_alg_name = args['alg_name']
    chosen_alg = [n for n in training_algs if n.name() == chosen_alg_name][0]

    training_dir = join("Training", training_dir_name(chosen_alg_name, args['seed']))
    args['training_dir'] = training_dir
    args['summary_dir'] = join(training_dir, 'summary')
    args['ckpt_dir'] = join(training_dir, 'checkpoints')

    pp.pprint(args)

    chosen_alg.train(args)