--- CODE README ---

We provide two code-bases which are similarly named - this is due to them being branches on the same repo, which we use for our work.

> CAPS-GymBenchmarks is the folder containing code for runing CAPS on the OpenAI Gym Benchmarks
> CAPS-Toy contains code for our toy problem discussed in the paper, as well as CAPS code for training on this problem.