# PPOSGD

**This code was adapted from an older version of [OpenAI baselines](https://github.com/openai/baselines), with specific files copied for this project**

- Original paper: https://arxiv.org/abs/1707.06347
- Baselines blog post: https://blog.openai.com/openai-baselines-ppo/

